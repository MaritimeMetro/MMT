metro@manitowoc.org
920-686-3560Contact InformationMaritime Metro Transit<font color="#ffff00">Route 2 Bus Stops</font><font color="#ffff00">
</font><font color="#ffff00">Franklin Street / S. 9th Street</font><font color="#ffff00">
</font><font color="#ffff00">:01/:31     </font><font color="#ffff00">
</font><font color="#ffff00"><b>Mtwc Public Library (S. 8th Street / Quay Street)</b></font><font color="#ffff00">
</font><font color="#ffff00"><b>:02 / :32</b></font><font color="#ffff00">
</font><font color="#ffff00"><b>WI Maritime Muesum</b></font><font color="#ffff00">
</font><font color="#ffff00"><b>:03 / :33</b></font><font color="#ffff00">
</font><font color="#ffff00"><b>YMCA (Maritime Drive)</b></font><font color="#ffff00">
</font><font color="#ffff00"><b>:03 / :33</b></font><font color="#ffff00">
</font><font color="#ffff00">Maritime Drive / Marina Park N' Ride</font><font color="#ffff00">
</font><font color="#ffff00">:04 / :34</font><font color="#ffff00">
</font><font color="#ffff00">Maritime Drive / Huron Street</font><font color="#ffff00">
</font><font color="#ffff00">:04 / :34</font><font color="#ffff00">
</font><font color="#ffff00"><b>Maritime Drive / PO Office</b></font><font color="#ffff00">
</font><font color="#ffff00"><b>:05 / :35</b></font><font color="#ffff00">
</font><font color="#ffff00"><b>Social Security Office</b></font><font color="#ffff00">
</font><font color="#ffff00"><b>:07 / :37</b></font><font color="#ffff00">
</font><font color="#ffff00">Mirro Drive / Oriole Road</font><font color="#ffff00">
</font><font color="#ffff00">:07 / :37</font><font color="#ffff00">
</font><font color="#ffff00">Mirro Drive / E. Ivy Lane</font><font color="#ffff00">
</font><font color="#ffff00">:07 / :37</font><font color="#ffff00">
</font><font color="#ffff00"><b>Roncalli High School</b></font><font color="#ffff00">
</font><font color="#ffff00"><b>:08 / :38</b></font><font color="#ffff00">
</font><font color="#ffff00"><b>Meadow Links Transfer Point</b></font><font color="#ffff00">
</font><font color="#ffff00"><b>:10 / :40</b></font><font color="#ffff00">
</font><font color="#ffff00">Johnston Drive / Linden Avenue</font><font color="#ffff00">
</font><font color="#ffff00">:11 / :41</font><font color="#ffff00">
</font><font color="#ffff00"><b>Younkers (Johnston Drive / Magnolia Avenue)</b></font><font color="#ffff00">
</font><font color="#ffff00"><b>:11 / :41</b></font><font color="#ffff00">
</font><font color="#ffff00">Johnston Drive / Reed Avenue</font><font color="#ffff00">
</font><font color="#ffff00">:12 / :42</font><font color="#ffff00">
</font><font color="#ffff00">Reed Avenue / DVC</font><font color="#ffff00">
</font><font color="#ffff00">:13 / :43</font><font color="#ffff00">
</font><font color="#ffff00">Reed Avenue / N. 3rd Street</font><font color="#ffff00">
</font><font color="#ffff00">:13 / :43</font><font color="#ffff00">
</font><font color="#ffff00"><b>River Hills Apartments</b></font><font color="#ffff00">
</font><font color="#ffff00"><b>:13 / :33</b></font><font color="#ffff00">
</font><font color="#ffff00"><b>Manitou Manor</b></font><font color="#ffff00">
</font><font color="#ffff00"><b>:14 / :44</b></font><font color="#ffff00">
</font><font color="#ffff00">Magnolia Avenue / N. 7th Street</font><font color="#ffff00">
</font><font color="#ffff00">:15 / :45</font><font color="#ffff00">
</font><font color="#ffff00">Magnolia Avenue / N. 8th Street*</font><font color="#ffff00">
</font><font color="#ffff00">:16 / :46</font><font color="#ffff00">
</font><font color="#ffff00">N. 8th Street / Fire Station 2</font><font color="#ffff00">
</font><font color="#ffff00">:17 / :47</font><font color="#ffff00">
</font><font color="#ffff00"><b>Piggly Wiggly Shelter</b></font><font color="#ffff00">
</font><font color="#ffff00"><b>:17 / :47</b></font><font color="#ffff00">
</font><font color="#ffff00">N. 8th Street / School Street</font><font color="#ffff00">
</font><font color="#ffff00">:18 / :48</font><font color="#ffff00">
</font><font color="#ffff00">Lincoln Blvd / Pine Street</font><font color="#ffff00">
</font><font color="#ffff00">:20 / :50</font><font color="#ffff00">
</font><font color="#ffff00">Lincoln Blvd / New York Avenue*</font><font color="#ffff00">
</font><font color="#ffff00">:21 / :51</font><font color="#ffff00">
</font><font color="#ffff00">N. 7th Street / Huron Street*</font><font color="#ffff00">
</font><font color="#ffff00">:21 / :51</font><font color="#ffff00">
</font><font color="#ffff00">N. 7th Street / St. Clair Street</font><font color="#ffff00">
</font><font color="#ffff00">:21 / :51</font><font color="#ffff00">
</font><font color="#ffff00">N. 7th Street / Park Street</font><font color="#ffff00">
</font><font color="#ffff00">:21 / :51</font><font color="#ffff00">
</font><font color="#ffff00"><b>Lakeshore CAP </b></font><font color="#ffff00">(N. 7th Street / State Street)</font><font color="#ffff00">
</font><font color="#ffff00"><b>:22 / :52</b></font><font color="#ffff00">
</font><font color="#ffff00">N. 7th Street / Chicago Street</font><font color="#ffff00">
</font><font color="#ffff00">:22 / :52</font><font color="#ffff00">
</font><font color="#ffff00">Chicago Street / N. 8th Street*</font><font color="#ffff00">
</font><font color="#ffff00">:22 / :52</font><font color="#ffff00">
</font><font color="#ffff00">Chicago Street / N. 9th Street*</font><font color="#ffff00">
</font><font color="#ffff00">:23 / :53</font><font color="#ffff00">
</font><font color="#ffff00">Chicago Street / N. 10th Street*</font><font color="#ffff00">
</font><font color="#ffff00">:23 / :53</font>
</h2Where can I buy a bus pass?Maritime Metro<font color="#6aa84f">Route 1 Bus Stops</font>
<font color="#6aa84f">Meadow Links Transfer Point :10</font>
<font color="#6aa84f">Johnston Dr. / Linden Ave. (The Galley) :15</font>
<font color="#6aa84f">Johnston Dr. / Magnolia Ave.  :15</font>
<font color="#6aa84f">CVS                      :16</font>
<font color="#6aa84f">Memorial Drive Wayside   :17</font>
<font color="#6aa84f">Woodland Clinic:20</font>
<font color="#6aa84f">Aurora Clinic Shelter (Into Two Rivers):20</font>
<font color="#6aa84f">Aurora Hospital (Into Two Rivers):20</font>
<font color="#6aa84f">Memorial Drive / Davis Street:21</font>
<font color="#6aa84f">Memorial Drive / Thiede Street:22</font>
<font color="#6aa84f">Shoreline CU / Allstates Rigging:22</font>
<font color="#6aa84f">Columbus Street / 7th Street:22</font>
<font color="#6aa84f">Columbus Street / 10th Street:22</font>
<font color="#6aa84f">Columbus Street / 12th Street*:23</font>
<font color="#6aa84f">18th Street / Ironwood Plastics:24</font>
<font color="#6aa84f">18th Street / Architectural Forest Products:24</font>
<font color="#6aa84f">Buchholz Street / 17th Street:24</font>
<font color="#6aa84f">Buchholz Street / 14th Street:24</font>
<font color="#6aa84f">14th Street / Lowell Street:25</font>
<font color="#6aa84f">12th Street / Victory Street:27</font>
<font color="#6aa84f">12th Street / School Street:27</font>
<font color="#6aa84f">Jerry's Bakery / Madison Street:28Two Rivers Senior Center:30</font>
<font color="#6aa84f">18th Street / Monroe Street*:30</font>
<font color="#6aa84f">Monroe street / 21st Street:31</font>
<font color="#6aa84f">Piggly Wiggly (Forest Ave / 23rd Street):31</font>
<font color="#6aa84f">Village Green West (Forest Ave / 26th Street):32</font>
<font color="#6aa84f">Forest Ave / 29th Street:32Forest Ave / Mueller Manor:33</font>
<font color="#6aa84f">Mishicot Road / 34th Street:33</font>
<font color="#6aa84f">Bellevue Place / 39th Street:34</font>
<font color="#6aa84f">Bellevue Place / 42nd Street:34</font>
<font color="#6aa84f">Bellevue Place / 44th Street:34</font>
<font color="#6aa84f">Bellevue Place / 42nd Street:34</font>
<font color="#6aa84f">Bellevue Place / 45th Street*:35</font>
<font color="#6aa84f">45th Street / Tannery Road:36</font>
<font color="#6aa84f">Tannery Road /   43rd Street:36</font>
<font color="#6aa84f">Tannery Road / 41st Street:36</font>
<font color="#6aa84f">Tannery Road / 37th Street:37</font>
<font color="#6aa84f">Monroe Street / 35th Street:38</font>
<font color="#6aa84f">Monroe Street / 34th Street*:39</font>
<font color="#6aa84f">Monroe Street / School Street*:39Monroe Street / 30th Street*:40</font>
<font color="#6aa84f">30th Street / Adams Street*:40</font>
<font color="#6aa84f">Adams Street / 27th Street*:41</font>
<font color="#6aa84f">27th Street / Washington Street*:41</font>
<font color="#6aa84f">Washington Street / 25th Street:42</font>
<font color="#6aa84f">Washington Street / 23rd Street:43</font>
<font color="#6aa84f">22nd Street / East River Street:43Pick 'n Save (Jackson Street / 22nd   Street):45</font>
<font color="#6aa84f">Jackson Street / 25th Street:46</font>
<font color="#6aa84f">Jackson Street / 31st Street*:47</font>
<font color="#6aa84f">Jackson Street / 34th Street*:47</font>
<font color="#6aa84f">34th Street / Lincoln Avenue*:48</font>
<font color="#6aa84f">29th Street / Garfield Street*:48</font>
<font color="#6aa84f">24th Street / Garfield Street*:49</font>
<font color="#6aa84f">Garfield Street / 25th Street*:49</font>
<font color="#6aa84f">24th Street / Polk Street:50</font>
<font color="#6aa84f">Polk Street / 22nd Street*:50</font>
<font color="#6aa84f">Neshotah Beach Shelter (Pierce Street):51Neshotah Beach (Pierce Street / Zlatnik Dr)*:51</font>
<font color="#6aa84f">17th Street / Lincoln Avenue:51</font>
<font color="#6aa84f">17th Street / East Street*:52</font>
<font color="#6aa84f">17th Street / Jefferson Street*:52</font>
<font color="#6aa84f">17th Street / East Park Street:53Downtown (Washington Street / 15th Street):55Lester Public Library (12th Street / Adams Street):56</font>
<font color="#6aa84f">12th Street / Madison Street*:57</font>
<font color="#6aa84f">12th Street / Roosevelt:58</font>
<font color="#6aa84f">HFM Clinic (9th / Roosevelt):58</font>
<font color="#6aa84f">Roosevelt Ave / Lowell Street*:58</font>
<font color="#6aa84f">Lakeview Motel:58</font>
<font color="#6aa84f">Memorial Drive / Gardner Street:59</font>
<font color="#6aa84f">Memorial Drive / Davis Street:59Aurora Hospital (Into Manitowoc):00</font>
<font color="#6aa84f">Aurora Clinic Shelter (Into Manitowoc):00Woodland Clinic:00Social Security Office:03</font>
<font color="#6aa84f">Mirro Dive / Oriole Road:04</font>
<font color="#6aa84f">Mirro Drive / E. Ivy Lane:04Roncalli High School:05</font>
<font color="#6aa84f">Albert Drive / Johnston Drive:06</font><font color="#f6b26b">Route 3 Bus Stops</font><font color="#f6b26b">
</font><font color="#f6b26b">Franklin Street / S. 13th Street</font><font color="#f6b26b">
</font><font color="#f6b26b">:01 / :31    </font><font color="#f6b26b">
</font><font color="#f6b26b">Franklin Street / S. 18th Street                       :02 / :32</font><font color="#f6b26b">
</font><font color="#f6b26b">Franklin Street / S. 22nd Street</font><font color="#f6b26b">
</font><font color="#f6b26b">:03 / :33</font><font color="#f6b26b">
</font><font color="#f6b26b">Franklin Street / S. 25th Street</font><font color="#f6b26b">
</font><font color="#f6b26b">:03 / :33</font><font color="#f6b26b">
</font><font color="#f6b26b">S. 26th Street / Washington Street</font><font color="#f6b26b">
</font><font color="#f6b26b">:04 / :34</font><font color="#f6b26b">
</font><font color="#f6b26b">Custer Street / Railroad Tracks</font><font color="#f6b26b">
</font><font color="#f6b26b">:04 / :34</font><font color="#f6b26b">
</font><font color="#f6b26b">Custer Street / S. 29th Street</font><font color="#f6b26b">
</font><font color="#f6b26b">:04 / :34</font><font color="#f6b26b">
</font><font color="#f6b26b">Manitowoc Senior Center</font><font color="#f6b26b">
</font><font color="#f6b26b">:04 / :34</font><font color="#f6b26b">
</font><font color="#f6b26b">Copps Bus Shelter</font><font color="#f6b26b">
</font><font color="#f6b26b">:05 / :35</font><font color="#f6b26b">
</font><font color="#f6b26b">Calumet Ave / S. 37th Street</font><font color="#f6b26b">
</font><font color="#f6b26b">:07 / :37</font><font color="#f6b26b">
</font><font color="#f6b26b">Calumet Ave / S. 39th Street </font><font color="#f6b26b">
</font><font color="#f6b26b">:07 / :37</font><font color="#f6b26b">
</font><font color="#f6b26b">Four Season's Restaurant Photo</font><font color="#f6b26b">
</font><font color="#f6b26b">:07 / :37</font><font color="#f6b26b">
</font><font color="#f6b26b">Shell Gas Station</font><font color="#f6b26b">
</font><font color="#f6b26b">:08 / :38</font><font color="#f6b26b">
</font><font color="#f6b26b">HFM Harbor Town Clinic Photo</font><font color="#f6b26b">
</font><font color="#f6b26b">:08 / :38</font><font color="#f6b26b">
</font><font color="#f6b26b">Grand Ave / S. 39th Street*</font><font color="#f6b26b">
</font><font color="#f6b26b">:11 / :41</font><font color="#f6b26b">
</font><font color="#f6b26b">West Side Transfer Point</font><font color="#f6b26b">
</font><font color="#f6b26b">:12 / :42</font><font color="#f6b26b">
</font><font color="#f6b26b">Walmart Bus Shelter*Photo</font><font color="#f6b26b">
</font><font color="#f6b26b">:15 / :42</font><font color="#f6b26b">
</font><font color="#f6b26b">Culvers / OfficeMax / AMC</font><font color="#f6b26b">
</font><font color="#f6b26b">:17 / :47</font><font color="#f6b26b">
</font><font color="#f6b26b">Festival Foods</font><font color="#f6b26b">
</font><font color="#f6b26b">:17 / :47</font><font color="#f6b26b">
</font><font color="#f6b26b">Dewey Street / S. 39th Street</font><font color="#f6b26b">
</font><font color="#f6b26b">:17 / :47</font><font color="#f6b26b">
</font><font color="#f6b26b">Job Center / LTC (on demand only)***</font><font color="#f6b26b">
</font><font color="#f6b26b">:17 / :47</font><font color="#f6b26b">
</font><font color="#f6b26b">Job Center / LTC Exit*</font><font color="#f6b26b">
</font><font color="#f6b26b">:17 / :47</font><font color="#f6b26b">
</font><font color="#f6b26b">S. 30th Street / Mobil Station</font><font color="#f6b26b">
</font><font color="#f6b26b">:18 / :48</font><font color="#f6b26b">
</font><font color="#f6b26b">S. 30th Street / Yorkshire Lane</font><font color="#f6b26b">
</font><font color="#f6b26b">:18 / :48</font><font color="#f6b26b">
</font><font color="#f6b26b">S. 30th Street / Lakeside Foods</font><font color="#f6b26b">
</font><font color="#f6b26b">:19 / :49</font><font color="#f6b26b">
</font><font color="#f6b26b">S. 30th Street / Southbrook Court</font><font color="#f6b26b">
</font><font color="#f6b26b">:20 / :50</font><font color="#f6b26b">
</font><font color="#f6b26b">Division Street / S. 31st Street</font><font color="#f6b26b">
</font><font color="#f6b26b">:20 / :50</font><font color="#f6b26b">
</font><font color="#f6b26b">Division Street / S. 35th Street*</font><font color="#f6b26b">
</font><font color="#f6b26b">:20 / :50</font><font color="#f6b26b">
</font><font color="#f6b26b">Shopko Store*</font><font color="#f6b26b">
</font><font color="#f6b26b">:22 / :52</font><font color="#f6b26b">
</font><font color="#f6b26b">Shopko Plaza / Bitter Neuman* Photo</font><font color="#f6b26b">
</font><font color="#f6b26b">:22 / :52</font><font color="#f6b26b">
</font><font color="#f6b26b">Shopko Plaza Exit / Calumet Avenue*</font><font color="#f6b26b">
</font><font color="#f6b26b">:22 / :52</font><font color="#f6b26b">
</font><font color="#f6b26b">Calumet Avenue / S. 31st Street</font><font color="#f6b26b">
</font><font color="#f6b26b">:22 / :52</font><font color="#f6b26b">
</font><font color="#f6b26b">Calumet Avenue / Railroad Tracks</font><font color="#f6b26b">
</font><font color="#f6b26b">:23 / :53</font><font color="#f6b26b">
</font><font color="#f6b26b">Washington Street / S. 24th Street</font><font color="#f6b26b">
</font><font color="#f6b26b">:23 / :53</font><font color="#f6b26b">
</font><font color="#f6b26b">Washington Street / S. 22nd Street</font><font color="#f6b26b">
</font><font color="#f6b26b">:23 / :53</font><font color="#f6b26b">
</font><font color="#f6b26b">Washington Street / S. 20th Street</font><font color="#f6b26b">
</font><font color="#f6b26b">:23 / :53</font><font color="#f6b26b">
</font><font color="#f6b26b">Washington Street / S. 16th Street</font><font color="#f6b26b">
</font><font color="#f6b26b">:24 / :54</font><font color="#f6b26b">
</font><font color="#f6b26b">Washington Street / S. 13th Street</font><font color="#f6b26b">
</font><font color="#f6b26b">:24 / :54</font>Maritime MetroMaritime Metro Transit<font color="#3c78d8"><b>Route 4 Bus Stops</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>Washington Street / S. 13th   Street                             :00 / :30     </b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>S. 14th Street / Marshall Street</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>:01 / :31</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>Marshall Street / S. 17th Street</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>:01 / :31</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>Marshall Street / S. 21st Street*</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>:03 / :33</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>Marshall Street / S. 22nd Street</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>:03 / :33</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>S. 24th Street / Hamilton Street*</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>:03 / :33</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>Shady Lane (S. 24th Street / Shady Lane)</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>:04 / :34</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>S. 24th Street / Division Street</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>:05 / :35</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>Washington Jr. High School</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>:05 / :35</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>Division Street / S. 21st Street</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>:06 / :36</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>Division Street / Felician Village</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>:06 / :36</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>Division Street / S. 16th Street*</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>:06 / :36</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>Jefferson Elementary School*</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>:06 / :36</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>S. 14th Street / Philipen Street</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>:07 / :37</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>S. 14th Street / Grand Avenue</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>:07 / :37</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>S. 14th Street / Dewey Street*</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>:08 / :38</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>S. 14th Street / Community Garden</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>:08 / :38</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>Monroe Elementary School</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>:09 / :39</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>S. 14th Street / Viebahn Street*</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>:09 / :39</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>Viebahn Street / S. 10th Street*</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>:09 / :39</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>Viebahn Street /    S. 21st Street</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>:12 / :42</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>Southfield Townhouses / S. 23rd Street</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>:15 / :45</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>University Manor / S. 23rd Street</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>:15 / :45</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>S. 23rd Street / Dewey Street</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>:17 / :47</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>Dewey Street / S. 18th Street*</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>:18 / :48</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>Dewey Street / S. 14th Street</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>:20 / :50</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>Dewey Street / S. 10th Street*</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>:20 / :50</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>S. 10th Street / Jaycee Drive</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>:20 / :50</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>S. 10th Street / Green Street</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>:21 / :51</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>S. 10th Street / Division Street</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>:21 / :51</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>S. 10th Street / Hamilton Street</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>:22 / :52</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>Marshall Street / S. 9th Street*</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>:22 / :52</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>Marshall Street / S. 8th Street*</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>:23 / :53</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>Marshall Street / S. 7th Street*</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>:23 / :53</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>S. 7th Street/ Hancock Street</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>:23 / :53</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>Manitowoc Public Library / Franklin Street</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>:23 / :53</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>Franklin Street / S. 9th Street</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b>:24 / :54</b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b> </b></font><font color="#3c78d8">
</font><font color="#3c78d8"><b> </b></font>Maritime Metro Transit<font color="#0b5394"><b>Route 5 Bus Stop</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>West Side Transfer Point</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>:11 / :51</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>Walmart Bus Shelter                            </b></font><font color="#0b5394">
</font><font color="#0b5394"><b>:12 / :42     </b></font><font color="#0b5394">
</font><font color="#0b5394"><b>Goodwill    Note:On   Demand Service</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>:16 / :46</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>Park-n-Ride (across from Perkins)</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>:16 / :46</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>Mendards</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>:17 / :47</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>Dufek Drive / Vits Drive (East side   of road)</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>:17 / :47</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>GKN Entrance</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>:17 / :47</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>Vits Drive / S. 59th Street</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>:17 / :47</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>Norther Labs (S. 59th Street)</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>:17 / :47</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>I-Tec Drive / West Drive</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>:18 / :48</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>I-Tec Drive / Calumet Avenue*</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>:19 / :49</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>Silver Lake Country Store</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>:19 / :49</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>Luigi's</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>:19 / :49</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>Silver Lake College / Claire Hall</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>:20 / :50</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>Silver Lake College Exit</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>:21 / :51</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>Manitowoc Health Care Center</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>:22 / :52</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>Americollect (Parking lot entrance)</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>:23 / :53</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>Alverno Road / Custer Street*</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>:25 / :55</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>W. Custer Street / S. 63rd Street</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>:25 / :55</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>W. Custer Street / S. 59th Street</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>:26 / :56</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>W. Custer Street / Dufek Drive</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>:26 / :56</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>W. Custer Street / Expo Drive</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>:26 / :56</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>Expo Drive / Custer Village Apts</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>:27 / :57</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>Expo Drive / Vista Road</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>:29 / :59</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>Eye Clinic / Expo Drive</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>:00 / :30</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>Kohls*</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>:02 / :32</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>Kohls / Exit to Harbor Town Lane</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>:03 / :33</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>Starbucks</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>:04 / :44</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>Harbor Town Lane / Dewey Street*</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>:05 / :35</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>Aldi / Petco</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>:06 / :36</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>Harbor Town Lane / S. 41st Street*</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>:09 / :39</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>Grand Avenue / S. 39th Street*</b></font><font color="#0b5394">
</font><font color="#0b5394"><b>:11 / :41</b></font><font color="#6aa84f">Route 6B Bus Stops</font><font color="#6aa84f">
</font><font color="#6aa84f"> </font><font color="#6aa84f">
</font><font color="#6aa84f">Clark Street / S. 15th Street</font><font color="#6aa84f">
</font><font color="#6aa84f">:31</font><font color="#6aa84f">
</font><font color="#6aa84f">Western Avenue / S. 17th Street</font><font color="#6aa84f">
</font><font color="#6aa84f">:31 </font><font color="#6aa84f">
</font><font color="#6aa84f">Western Avenue / S. 20th Street</font><font color="#6aa84f">
</font><font color="#6aa84f">:31 </font><font color="#6aa84f">
</font><font color="#6aa84f">Holy Family Memorial Hospital</font><font color="#6aa84f">
</font><font color="#6aa84f">:32</font><font color="#6aa84f">
</font><font color="#6aa84f">Western Avenue / S. 26th Street*</font><font color="#6aa84f">
</font><font color="#6aa84f">:33</font><font color="#6aa84f">
</font><font color="#6aa84f">Holiday House</font><font color="#6aa84f">
</font><font color="#6aa84f">:34 </font><font color="#6aa84f">
</font><font color="#6aa84f">Meadow Lane / S. 30th Street</font><font color="#6aa84f">
</font><font color="#6aa84f">:34 </font><font color="#6aa84f">
</font><font color="#6aa84f">Meadow Lane / S. 33rd Street</font><font color="#6aa84f">
</font><font color="#6aa84f">:34</font><font color="#6aa84f">
</font><font color="#6aa84f">S. 35th Street / MacArthur Drive</font><font color="#6aa84f">
</font><font color="#6aa84f">:35</font><font color="#6aa84f">
</font><font color="#6aa84f">S. 35th Street / Dale Street</font><font color="#6aa84f">
</font><font color="#6aa84f">:35</font><font color="#6aa84f">
</font><font color="#6aa84f">S. 35th Street / Custer Street*</font><font color="#6aa84f">
</font><font color="#6aa84f">:36</font><font color="#6aa84f">
</font><font color="#6aa84f">S. 37th Street / Custer Street</font><font color="#6aa84f">
</font><font color="#6aa84f">:36</font><font color="#6aa84f">
</font><font color="#6aa84f">S. 39th Street / Custer Street</font><font color="#6aa84f">
</font><font color="#6aa84f">:37</font><font color="#6aa84f">
</font><font color="#6aa84f">S. 41st Street / Custer Street</font><font color="#6aa84f">
</font><font color="#6aa84f">:37</font><font color="#6aa84f">
</font><font color="#6aa84f">Custer Street / Clipper Drive</font><font color="#6aa84f">
</font><font color="#6aa84f">:38</font><font color="#6aa84f">
</font><font color="#6aa84f">Fleet Farm / Custer Street</font><font color="#6aa84f">
</font><font color="#6aa84f">:38</font><font color="#6aa84f">
</font><font color="#6aa84f">River's Bend </font><font color="#6aa84f">(on demand only)***</font><font color="#6aa84f">
</font><font color="#6aa84f">:39</font><font color="#6aa84f">
</font><font color="#6aa84f">N. Rapids Road / Conroe Street</font><font color="#6aa84f">
</font><font color="#6aa84f">:40</font><font color="#6aa84f">
</font><font color="#6aa84f">N. Rapids Road / Ellis Street</font><font color="#6aa84f">
</font><font color="#6aa84f">:40 </font><font color="#6aa84f">
</font><font color="#6aa84f">N. Rapids Road / Michigan Avenue</font><font color="#6aa84f">
</font><font color="#6aa84f"> :41</font><font color="#6aa84f"> </font><font color="#6aa84f">
</font><font color="#6aa84f">Waldo Blvd / Glenview Drive</font><font color="#6aa84f">
:41
</font><font color="#6aa84f">Waldo     Blvd / Fleetwood Drive</font><font color="#6aa84f">
</font><font color="#6aa84f">: 42</font><font color="#6aa84f">
</font><font color="#6aa84f">N.     23rd Street / Fairmont Street   </font><font color="#6aa84f">
</font><font color="#6aa84f">  :43</font><font color="#6aa84f">
</font><font color="#6aa84f">N.     23rd Street / Granger Road       </font><font color="#6aa84f">
</font><font color="#6aa84f"> :43</font><font color="#6aa84f">
</font><font color="#6aa84f">Robs Market (Menasha Ave / N. 23rd Street)*    </font><font color="#6aa84f">
</font><font color="#6aa84f"> :44</font><font color="#6aa84f">
</font><font color="#6aa84f">Menasha Avenue / N.   21st Street</font><font color="#6aa84f">
</font><font color="#6aa84f">:44 </font><font color="#6aa84f">
</font><font color="#6aa84f">Menasha Avenue / N. 18th Street*</font><font color="#6aa84f">
</font><font color="#6aa84f">:45 </font><font color="#6aa84f">
</font><font color="#6aa84f">Jackson School (N. 18th Street / Fairmont Street)</font><font color="#6aa84f">
</font><font color="#6aa84f"> :46</font><font color="#6aa84f">
</font><font color="#6aa84f">  </font><font color="#6aa84f">Aquatic Center </font><font color="#6aa84f">(N. 18th Street)</font><font color="#6aa84f">
</font><font color="#6aa84f">:48</font><font color="#6aa84f"> 
</font><font color="#6aa84f">New York Avenue / N. 17th Street</font><font color="#6aa84f">
</font><font color="#6aa84f">:48</font><font color="#6aa84f"> 
</font><font color="#6aa84f">New York Avenue / N. 14th Street</font><font color="#6aa84f">
</font><font color="#6aa84f">:49</font><font color="#6aa84f"> 
</font><font color="#6aa84f">New York Avenue / N. 12th Street</font><font color="#6aa84f">
</font><font color="#6aa84f">:49</font><font color="#6aa84f"> 
</font><font color="#6aa84f">New York Avenue / N. 11th Street*</font><font color="#6aa84f">
</font><font color="#6aa84f">:49</font><font color="#6aa84f"> 
</font><font color="#6aa84f">McKinley Academy (N. 11th St / Huron St*)</font><font color="#6aa84f">
</font><font color="#6aa84f">:50</font><font color="#6aa84f"> 
</font><font color="#6aa84f">N. 10th Street / State Street</font><font color="#6aa84f">
</font><font color="#6aa84f">:51</font><font color="#6aa84f">
</font><font color="#6aa84f">N. 10th Street / Buffalo Stre</font><font color="#6aa84f">
:52
</fontMaritime Metro TransitMaritime Metro Transit<font color="#93c47d">Route 6B Bus Stops  Clark Street / S.   15th Street:01  Western Avenue / S.   17th Street:01          Western Avenue / S.   20th Street:01 Holy Family Memorial   Hospital:02  Western Avenue / S.   26th Street*:03 Holiday House:04 Meadow Lane / S.   30th Street:04  Meadow Lane / S.   33rd Street:04  S. 35th Street /   MacArthur Drive:05 S. 35th Street /   Dale Street:05 S. 35th Street /   Custer Street*:06 S. 37th Street /   Custer Street:06S. 39th Street /   Custer Street:07 S. 41st Street /   Custer Street:07 Custer Street /   Clipper Drive:08Fleet Farm / Custer   Street:08River's Bend (on demand only)***:09N. Rapids Road /   Conroe Street:10 N. Rapids Road /   Ellis Street:10 N. Rapids Road /   Michigan Avenue:11 Lutheran High / Wildwood:12Kellner Street / Hubbard Circle:12Kellner Street / Lee Circle:12Kellner Street / Andrea Lane:12Kellner Street / Menasha Avenue*:13Menasha Avenue / Knuell Street:13Menasha Avenue / Platt Street:13Menasha Avenue / Herman Road:13Menasha Avenue / N. 30th Street:14First Class Cafe:14Robs Market (Menasha   Ave / N. 23rd Street)* :12 :12 :12 :13 :13 :13 :14 :14 :14 :14</font>
<font color="#93c47d">Menasha Avenue / N. 21st Street:14Menasha Avenue / N.   18th Street*:15Jackson School (N.   18th Street / Fairmont Street):16Aquatic Center (N. 18th Street):18</font>
<font color="#93c47d">New York Avenue / N.   17th Street:18</font>
<font color="#93c47d">New York Avenue / N.   14th Street:19</font>
<font color="#93c47d">New York Avenue / N.   12th Street:19</font>
<font color="#93c47d">New York Avenue / N.   11th Street*:19</font>
<font color="#93c47d">McKinley Academy (N.   11th St / Huron St*):20</font>
<font color="#93c47d">N. 10th Street /   State Street:21</font>
<font color="#93c47d">N. 10th Street /   Buffalo Street:22</font>










Maritime Metro Transit<font color="#ffff00">Route 2 Bus Stops</font><font color="#ffff00">
</font><font color="#ffff00">Franklin Street / S. 9th Street</font><font color="#ffff00">
</font><font color="#ffff00">:01/:31     </font><font color="#ffff00">
</font><font color="#ffff00"><b>Mtwc Public Library (S. 8th Street / Quay Street)</b></font><font color="#ffff00">
</font><font color="#ffff00"><b>:02 / :32</b></font><font color="#ffff00">
</font><font color="#ffff00"><b>WI Maritime Muesum</b></font><font color="#ffff00">
</font><font color="#ffff00"><b>:03 / :33</b></font><font color="#ffff00">
</font><font color="#ffff00"><b>YMCA (Maritime Drive)</b></font><font color="#ffff00">
</font><font color="#ffff00"><b>:03 / :33</b></font><font color="#ffff00">
</font><font color="#ffff00">Maritime Drive / Marina Park N' Ride</font><font color="#ffff00">
</font><font color="#ffff00">:04 / :34</font><font color="#ffff00">
</font><font color="#ffff00">Maritime Drive / Huron Street</font><font color="#ffff00">
</font><font color="#ffff00">:04 / :34</font><font color="#ffff00">
</font><font color="#ffff00"><b>Maritime Drive / PO Office</b></font><font color="#ffff00">
</font><font color="#ffff00"><b>:05 / :35</b></font><font color="#ffff00">
</font><font color="#ffff00"><b>Social Security Office</b></font><font color="#ffff00">
</font><font color="#ffff00"><b>:07 / :37</b></font><font color="#ffff00">
</font><font color="#ffff00">Mirro Drive / Oriole Road</font><font color="#ffff00">
</font><font color="#ffff00">:07 / :37</font><font color="#ffff00">
</font><font color="#ffff00">Mirro Drive / E. Ivy Lane</font><font color="#ffff00">
</font><font color="#ffff00">:07 / :37</font><font color="#ffff00">
</font><font color="#ffff00"><b>Roncalli High School</b></font><font color="#ffff00">
</font><font color="#ffff00"><b>:08 / :38</b></font><font color="#ffff00">
</font><font color="#ffff00"><b>Meadow Links Transfer Point</b></font><font color="#ffff00">
</font><font color="#ffff00"><b>:10 / :40</b></font><font color="#ffff00">
</font><font color="#ffff00">Johnston Drive / Linden Avenue</font><font color="#ffff00">
</font><font color="#ffff00">:11 / :41</font><font color="#ffff00">
</font><font color="#ffff00"><b>Younkers (Johnston Drive / Magnolia Avenue)</b></font><font color="#ffff00">
</font><font color="#ffff00"><b>:11 / :41</b></font><font color="#ffff00">
</font><font color="#ffff00">Johnston Drive / Reed Avenue</font><font color="#ffff00">
</font><font color="#ffff00">:12 / :42</font><font color="#ffff00">
</font><font color="#ffff00">Reed Avenue / DVC</font><font color="#ffff00">
</font><font color="#ffff00">:13 / :43</font><font color="#ffff00">
</font><font color="#ffff00">Reed Avenue / N. 3rd Street</font><font color="#ffff00">
</font><font color="#ffff00">:13 / :43</font><font color="#ffff00">
</font><font color="#ffff00"><b>River Hills Apartments</b></font><font color="#ffff00">
</font><font color="#ffff00"><b>:13 / :33</b></font><font color="#ffff00">
</font><font color="#ffff00"><b>Manitou Manor</b></font><font color="#ffff00">
</font><font color="#ffff00"><b>:14 / :44</b></font><font color="#ffff00">
</font><font color="#ffff00">Magnolia Avenue / N. 7th Street</font><font color="#ffff00">
</font><font color="#ffff00">:15 / :45</font><font color="#ffff00">
</font><font color="#ffff00">Magnolia Avenue / N. 8th Street*</font><font color="#ffff00">
</font><font color="#ffff00">:16 / :46</font><font color="#ffff00">
</font><font color="#ffff00">N. 8th Street / Fire Station 2</font><font color="#ffff00">
</font><font color="#ffff00">:17 / :47</font><font color="#ffff00">
</font><font color="#ffff00"><b>Piggly Wiggly Shelter</b></font><font color="#ffff00">
</font><font color="#ffff00"><b>:17 / :47</b></font><font color="#ffff00">
</font><font color="#ffff00">N. 8th Street / School Street</font><font color="#ffff00">
</font><font color="#ffff00">:18 / :48</font><font color="#ffff00">
</font><font color="#ffff00">Lincoln Blvd / Pine Street</font><font color="#ffff00">
</font><font color="#ffff00">:20 / :50</font><font color="#ffff00">
</font><font color="#ffff00">Lincoln Blvd / New York Avenue*</font><font color="#ffff00">
</font><font color="#ffff00">:21 / :51</font><font color="#ffff00">
</font><font color="#ffff00">N. 7th Street / Huron Street*</font><font color="#ffff00">
</font><font color="#ffff00">:21 / :51</font><font color="#ffff00">
</font><font color="#ffff00">N. 7th Street / St. Clair Street</font><font color="#ffff00">
</font><font color="#ffff00">:21 / :51</font><font color="#ffff00">
</font><font color="#ffff00">N. 7th Street / Park Street</font><font color="#ffff00">
</font><font color="#ffff00">:21 / :51</font><font color="#ffff00">
</font><font color="#ffff00"><b>Lakeshore CAP </b></font><font color="#ffff00">(N. 7th Street / State Street)</font><font color="#ffff00">
</font><font color="#ffff00"><b>:22 / :52</b></font><font color="#ffff00">
</font><font color="#ffff00">N. 7th Street / Chicago Street</font><font color="#ffff00">
</font><font color="#ffff00">:22 / :52</font><font color="#ffff00">
</font><font color="#ffff00">Chicago Street / N. 8th Street*</font><font color="#ffff00">
</font><font color="#ffff00">:22 / :52</font><font color="#ffff00">
</font><font color="#ffff00">Chicago Street / N. 9th Street*</font><font color="#ffff00">
</font><font color="#ffff00">:23 / :53</font><font color="#ffff00">
</font><font color="#ffff00">Chicago Street / N. 10th Street*</font><font color="#ffff00">
</font><font color="#ffff00">:23 / :53</font>
</h2<font color="#ffffff">Maritime Metro Transit is the premiere public transportation option in Manitowoc and Two Rivers. Maritime Metro Transit operates six fixed routes throughout the two cities and offers citizens an inexpensive transportation option to work, school, and everywhere in between. Maritime Metro Transit's long history of being a socio-economical resource to the Lakeshore Area has contributed to the success and well being of the citizens, businesses, and visitors of the area.</font><h1>Fares
</h1>
Adult Cash Fare18 - 64 $1.50
Student Cash Fare with valid Student ID $1.00
Elderly Cash Fare*65 and older $0.75
Persons with a Disability Cash Fare* $0.75
Children Four Years Old and under Free
Monthly Bus Pass $28.00
Summer Freedom Pass
 (June - August)5 - 17 $30.00
Day Pass $4.00
Bus Tickets 10 for $12
Transfers Free
Groups (eight people or more) $0.50<h1>Location                                        Route </h1>
<h1>Two Rivers Senior Center        1</h1>
<h1>Pick N Save (Two Rivers)          1</h1>
<h1>Piggly Wiggly (Two Rivers)      1     </h1>
<h1>Piggly Wiggly (Manitowoc)      2</h1>
<h1>Pick N Save (Manitowoc)           3</h1>
<h1>Festival Foods                                   3</h1>
<h1>Manitowoc Senior Center        3</h1>
<h1>Rob's Family Market                    6</h1>
<h1>MMT  Transfer Center            2,3,4,6</h1>